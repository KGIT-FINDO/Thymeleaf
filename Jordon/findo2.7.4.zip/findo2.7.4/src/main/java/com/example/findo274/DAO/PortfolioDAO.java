package com.example.findo274.DAO;

public interface PortfolioDAO {
}
