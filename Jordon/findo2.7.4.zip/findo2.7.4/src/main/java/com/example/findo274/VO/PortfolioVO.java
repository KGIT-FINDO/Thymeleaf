package com.example.findo274.VO;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class PortfolioVO {
    private int no;
    private String id;
    private String stock_name;
    private int volume;
};