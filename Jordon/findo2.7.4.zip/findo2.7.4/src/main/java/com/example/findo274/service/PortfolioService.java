package com.example.findo274.service;

public interface PortfolioService {
}
