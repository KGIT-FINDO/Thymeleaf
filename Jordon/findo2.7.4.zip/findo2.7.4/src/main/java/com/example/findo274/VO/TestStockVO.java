package com.example.findo274.VO;

import lombok.Data;
import org.json.simple.JSONObject;

@Data
public class TestStockVO {
    private JSONObject stock;
}
